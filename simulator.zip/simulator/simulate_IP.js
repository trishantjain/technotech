require("dotenv").config();
const net = require("net");
const path = require("path");
const csv = require("csv-parser");
const fs = require("fs");
// const { connected } = require('process');
const WebSocket = require("ws");

const args = process.argv;

// const TOTAL_DEVICES = 156;
// const TOTAL_DEVICES = process.env.TOTAL_DEVICES;
const TOTAL_DEVICES = Number(args[2]) || 100;
const devices = [];
let csvData = [];
let currentSecond = 0;
let isCSVMode = false;

const simulatorState = {
  insideTemperature: 55,
  outsideTemperature: 26,
  outputVoltage: 222,
  inputVoltage: 33,
  humidity: 60,
  hupsDVC: 20,
  hupsBat: 33,
  batteryBackup: 4,
  fireAlarm: false,
  leakage: true,
  logging: true,
  door: false,
  lock: false,
  password: false,
  // Fan overrides from UI: when true, force that fan to status 2 (FAIL) in outgoing packets
  fan1: false,
  fan2: false,
  fan3: false,
  fan4: false,
  fan5: false,
  fan6: false,
  // mode: "manual",
  mode: "random"
};

// 🔥 PRE-INDEXING: Fast lookup structure
let csvDataBySecond = new Map(); // { second → [row1, row2, ...] }

let PADDING_BYTE = 0;

const connectedDevices = new Map();

const wss = new WebSocket.Server({ port: 8090 });

console.log("📡 WebSocket server started on ws://localhost:8090");

wss.on("connection", (ws) => {
  console.log(" UI Client connected");

  // Sending current 'simulatorState' to UI
  ws.send(JSON.stringify(simulatorState));

  ws.on("message", (message) => {
    try {
      const updatedData = JSON.parse(message.toString());

      console.log("updated data: ", updatedData);

      // Normalize fan values coming from UI (supports legacy boolean and numeric)
      for (const fanKey of ["fan1", "fan2", "fan3", "fan4", "fan5", "fan6"]) {
        if (fanKey in updatedData) {
          const v = updatedData[fanKey];
          if (typeof v === "boolean") {
            updatedData[fanKey] = v;
          } else {
            // Back-compat: numeric 2 means "true" (force fail)
            const asNum = Number(v);
            updatedData[fanKey] = Number.isFinite(asNum)
              ? asNum === 2
              : Boolean(v);
          }
        }
      }

      // Update only provided fields in simulatorState
      Object.assign(simulatorState, updatedData);

      console.log("🔄 Updated simulator state from UI:", simulatorState);
    } catch (error) {
      console.error("Error parsing message:", error.stack);
    }
  });

  ws.on("close", () => {
    console.log(" UI Client disconnected");
  });
});

function startPaddingPulse() {
  console.log("🕒 Starting padding pulse (toggle every second)");

  let second = 0;

  setInterval(() => {
    // even second → 0
    // odd second → 63
    PADDING_BYTE = second % 2 === 0 ? 0x00 : 0x43;

    console.log(`🔁 Second ${second} → Padding ${PADDING_BYTE}`);

    second++;
  }, 3000);
}

startPaddingPulse();

// Start pulse schedule after 30s (previous behavior), returning controller if needed
// setTimeout(() => {
//   scheduleCameraClicker();
// }, 30000);

function generateIP(index) {
  // Previous implementation wrapped at 256, causing duplicate IDs and limiting
  // effective simulated devices to 256 (connectedDevices map key collisions).
  // Generate unique IPv4 IDs by spreading across subnets.
  // Uses host range 1..254 to avoid .0 and .255.
  const hostsPerSubnet = 254;
  const subnet = Math.floor(index / hostsPerSubnet); // 0..n
  const host = (index % hostsPerSubnet) + 1; // 1..254

  if (subnet > 255) {
    throw new Error(
      `TOTAL_DEVICES too large for 192.168.x.y scheme: index=${index} subnet=${subnet}`,
    );
  }

  return `192.168.${subnet}.${host}`;
}

function ipStringToAsciiHexBuffer(ip) {
  return Buffer.from(
    ip
      .split(".")
      .map((n) => parseInt(n, 10).toString(16).padStart(2, "0"))
      .join(""),
    "ascii",
  );
}

function toFloatLE(value) {
  const buf = Buffer.alloc(4);
  buf.writeFloatLE(value, 0);
  return buf;
}

function toShortLE(value) {
  const buf = Buffer.alloc(2);
  buf.writeInt16LE(value, 0);
  return buf;
}

// Reading CSV File
function readCSV(filePath) {
  return new Promise((resolve, reject) => {
    const results = [];
    const csv_path = path.resolve(filePath);

    const stream = fs.createReadStream(csv_path);

    stream.on("error", (err) => {
      reject(err);
    });

    stream
      .pipe(csv())
      .on("data", (row) => {
        const cleanedRow = {};
        Object.keys(row).forEach((key) => {
          cleanedRow[key] =
            typeof row[key] === "string" ? row[key].trim() : row[key];
        });
        results.push(cleanedRow);
      })
      .on("end", () => {
        resolve(results);
      })
      .on("error", (err) => {
        reject(err);
      });
  });
}

// // Fetching Data for particular second
// function getDataForSecond(second, ip) {
//   return csvData.find(row =>
//     parseInt(row.seconds) === second && row.ip === ip
//   );
// }

function preIndexCSVData() {
  console.log("⚡ Pre-indexing CSV data...");

  csvDataBySecond.clear(); // Clear any existing data

  // Index by SECOND (for dispatcher)
  csvData.forEach((row) => {
    const second = parseInt(row.seconds);
    if (!csvDataBySecond.has(second)) {
      csvDataBySecond.set(second, []);
    }
    csvDataBySecond.get(second).push(row);
  });

  console.log(`⚡ Indexed ${csvDataBySecond.size} seconds`);

  // Debug: Show index statistics
  console.log("📊 Index Statistics:");
  const secondsWithData = Array.from(csvDataBySecond.keys()).sort(
    (a, b) => a - b,
  );
  const maxDataInSecond = Math.max(
    ...Array.from(csvDataBySecond.values()).map((arr) => arr.length),
  );
  console.log(
    `   Seconds range: ${secondsWithData[0]} to ${secondsWithData[secondsWithData.length - 1]}`,
  );
  console.log(`   Most data in one second: ${maxDataInSecond}`);
}

function sendPacketForRow(client, row, ip, index) {
  const insideTemp = parseFloat(row.inside_temp) || 35 + Math.random() * 3;
  const outsideTemp =
    parseFloat(row.outside_temp) || insideTemp + 5 + Math.random() * 3;
  const waterLeakage =
    parseInt(row.water_leakage) || (Math.random() < 0.2 ? 1 : 0);
  const waterLogging =
    parseInt(row.water_logging) || (Math.random() < 0.2 ? 1 : 0);

  // Random values for other fields
  const humidity = parseFloat(row.humidity) || 55 + Math.random() * 5;
  const lockStatus = Math.random() < 0.5 ? 1 : 0;
  const doorStatus = 0;
  const inputVoltage = parseFloat(row.input_volt) || 33 + Math.random() * 2;
  const outputVoltage =
    parseFloat(row.output_volt) || 3.3 + Math.random() * 0.1;
  const batteryBackup = parseFloat(row.battery_back) || 12 + Math.random() * 3;

  const alarmActive = waterLogging || waterLeakage;
  const fireAlarm = 0;

  // Fan simulation (from original code)
  const fan1 = Math.random() < 0.9 ? 1 : 0;
  const fan2 = Math.random() < 0.9 ? 1 : 0;
  const fan3 = Math.random() < 0.9 ? 1 : 0;
  const fan4 = Math.random() < 0.9 ? 1 : 0;

  // Fan status codes (from original code)
  const fanStatuses = [];
  for (let i = 0; i < 6; i++) {
    const rand = Math.random();
    fanStatuses[i] = rand < 0.4 ? 0 : rand < 0.9 ? 1 : 2;
  }

  let fanStatusBits = 0;
  for (let i = 0; i < 6; i++) {
    fanStatusBits |= fanStatuses[i] << (i * 2);
  }
  const fanStatusBuf = Buffer.alloc(2);
  fanStatusBuf.writeUInt16LE(fanStatusBits, 0);

  // Fail mask (from original code)
  let failMask = 0;
  const failBuf = Buffer.alloc(4);
  failBuf.writeUInt32LE(failMask, 0);

  // Build packet
  const packet = Buffer.concat([
    Buffer.from(ip.padEnd(17, " "), "utf-8"),
    toFloatLE(humidity),
    toFloatLE(insideTemp),
    toFloatLE(outsideTemp),
    Buffer.from([lockStatus, doorStatus, waterLogging, waterLeakage]),
    toShortLE(outputVoltage),
    toFloatLE(inputVoltage),
    toFloatLE(batteryBackup),
    Buffer.from([
      alarmActive ? 1 : 0,
      fireAlarm,
      fan1,
      fan2,
      fan3,
      fan4,
      PADDING_BYTE, // padding (placed at offset 51)
    ]),
    fanStatusBuf,
    failBuf,
  ]);

  console.log(
    `[${ip}] CSV: Temp=${insideTemp}°C, WaterLeak=${waterLeakage}, WaterLog=${waterLogging}`,
  );
  // console.log(`[${ip}] Packet padding byte at offset 51: 0x${packet[51].toString(16)}`);
  client.write(packet);
}

function startDevice(ip, index) {
  try {
    // const client = net.createConnection({ host: '98.88.250.83', port: 4000 });
    // const client = net.createConnection({ host: '172.16.113.225', port: 4000 });
    const client = net.createConnection({ host: "localhost", port: 4000 });
    console.log("Client connected", ip);

    // 🔧 NEW: Store this device in our connected devices map
    connectedDevices.set(ip, client);

    client.on("connect", () => {
      console.log(`✅ Connected as ${ip}`);

      if (isCSVMode && csvData.length > 0) {
        console.log(`📄 ${ip} waiting for CSV data dispatcher...`);
        // Device will receive data from startDataDispatcher()
      } else if (!isCSVMode || csvData.length === 0) {
        // } else if (!isCSVMode === false) {
        console.log(`🔄 ${ip} starting in RANDOM mode`);

        // SENDING 1 PACKET / 3 SECONDS / DEVICE
        const SEND_INTERVAL = 5000; // 3 seconds
        const PHASE_OFFSET_MS = (index * 1000) / TOTAL_DEVICES;

        let sendCount = 0;
        const isHealthyDevice = index >= TOTAL_DEVICES - 2;
        const isDisconnectedSim =
          index >= TOTAL_DEVICES - 5 && index < TOTAL_DEVICES - 2;

        // DEVICE ALARM CLASSIFICATION
        let deviceAlarmType;

        if (index < TOTAL_DEVICES * 0.4) {
          deviceAlarmType = "STATUS";
        } else if (index < TOTAL_DEVICES * 0.8) {
          deviceAlarmType = "GAUGE";
        } else {
          deviceAlarmType = "BOTH";
        }

        let alarmStart = 5 + Math.floor(Math.random() * 5);
        let alarmDuration = 2 + Math.floor(Math.random() * 2);
        let inAlarmPhase = false;

        const interval = setInterval(() => {
          sendCount++;

          console.log(`\n🎲 [${ip}] RANDOM MODE - Packet #${sendCount}`);

          // Disconnection Simulation
          if (isDisconnectedSim && sendCount >= 3) {
            console.log(`❌ [${ip}] DISCONNECTING after ${sendCount} packets`);
            clearInterval(interval);
            connectedDevices.delete(ip); // 🔧 NEW: Remove from map
            client.end();

            const reconnectDelay = 10000 + Math.random() * 10000;
            console.log(
              `🔄 [${ip}] Will reconnect in ${(reconnectDelay / 1000).toFixed(1)}s`,
            );
            setTimeout(() => startDevice(ip, index), reconnectDelay);
            return;
          }

          // Toggle alarm phase
          if (isHealthyDevice) {
            console.log("Healthy device count");
            if (
              sendCount >= alarmStart &&
              sendCount < alarmStart + alarmDuration
            ) {
              inAlarmPhase = true;
              console.log(`🚨 [${ip}] ALARM PHASE ACTIVATED`);
            } else {
              inAlarmPhase = false;
              console.log(`✅ [${ip}] NORMAL PHASE`);
            }

            if (sendCount >= alarmStart + alarmDuration) {
              alarmStart = sendCount + 5 + Math.floor(Math.random() * 5);
              alarmDuration = 2 + Math.floor(Math.random() * 2);
              console.log(`🔄 [${ip}] Next alarm at packet #${alarmStart}`);
            }
          }

          // Overall alarm trigger
          const triggerAlarm = !isHealthyDevice || inAlarmPhase;

          // Independent alarm triggers
          const triggerGaugeAlarm =
            triggerAlarm &&
            (deviceAlarmType === "GAUGE" || deviceAlarmType === "BOTH");

          const triggerStatusAlarm =
            triggerAlarm &&
            (deviceAlarmType === "STATUS" || deviceAlarmType === "BOTH");

          // SENSOR DATA GENERATION

          // GAUGE ALARMS
          const humidity =
            simulatorState.mode === "random"
              ? triggerGaugeAlarm
                ? 85 + Math.random() * 10
                : 55 + Math.random() * 5
              : simulatorState.humidity;

          const insideTemp =
            simulatorState.mode === "random"
              ? triggerGaugeAlarm
                ? 55 + Math.random() * 10
                : 35 + Math.random() * 5
              : simulatorState.insideTemperature;

          const outsideTemp =
            simulatorState.mode === "random"
              ? triggerGaugeAlarm
                ? 65 + Math.random() * 10
                : 40 + Math.random() * 5
              : simulatorState.outsideTemperature;

          const inputVoltage = triggerGaugeAlarm
            ? 4000 + Math.random() * 10
            : 4000 + Math.random() * 10;

          const outputVoltage =
            simulatorState.mode === "random"
              ? triggerGaugeAlarm
                ? 5000 + Math.random() * 10
                : 5000 + Math.random() * 10
              : simulatorState.outputVoltage;

          const hupsDVC = triggerGaugeAlarm
            ? 2.5 + Math.random() * 10
            : 3.3 + Math.random() * 10;

          const hupsBat = triggerGaugeAlarm
            ? 2.5 + Math.random() * 10
            : 3.3 + Math.random() * 10;

          const batteryBackup = 3;

          // const batteryBackup = triggerAlarm ? 12 + Math.random() * 2 : 20 + Math.random() * 3;
          // const humidity = 82;
          // const insideTemp = 80;
          // const outsideTemp = 80;
          // const doorStatus = Math.random() < 0.5 ? 1 : 0;

          // STATUS ALARMS
          const lockStatus =
            simulatorState.mode === "random"
              ? triggerStatusAlarm
                ? 1
                : 0
              : simulatorState.lock
                ? 1
                : 0;

          const doorStatus =
            simulatorState.mode === "random"
              ? triggerStatusAlarm
                ? 1
                : 0
              : simulatorState.door
                ? 1
                : 0;

          const waterLogging =
            simulatorState.mode === "random"
              ? triggerStatusAlarm && Math.random() < 0.2
                ? 1
                : 0
              : simulatorState.logging
                ? 1
                : 0;

          const waterLeakage =
            simulatorState.mode === "random"
              ? !triggerStatusAlarm && Math.random() < 0.2
                ? 1
                : 0
              : simulatorState.leakage
                ? 1
                : 0;

          const fireAlarm =
            simulatorState.mode === "random"
              ? triggerStatusAlarm && Math.random() < 0.5
                ? 1
                : 0
              : simulatorState.fireAlarm
                ? 1
                : 0;

          const alarmActive = waterLogging || waterLeakage;

          // const inputVoltage = 80;
          // const fireAlarm = 1;

          // console.log("Lock Status: ", lockStatus);

          // INDIVIDUAL FAN STATUS (0=OFF, 1=ON, 2=FAIL)
          let fanStatuses = [];
          let fanGroupStatus = [0, 0, 0, 0];

          // if (simulatorState.mode === 'random') {
          if (insideTemp > 60) {
            fanStatuses = [1, 1, 1, 1, 1, 1];
            fanGroupStatus = [1, 1, 1, 1];
          } else if (insideTemp > 35) {
            fanStatuses = [1, 1, 1, 1, 1, 0];
            fanGroupStatus = [1, 1, 1, 0];
          } else if (insideTemp > 25) {
            fanStatuses = [1, 1, 1, 0, 0, 0];
            fanGroupStatus = [1, 1, 0, 0];
          } else {
            fanStatuses = [0, 0, 0, 0, 0, 0];
          }
          // } else {
          //   for (let i = 0; i < 6; i++) {
          //     const rand = Math.random();
          //     fanStatuses[i] = rand < 0.4 ? 0 : rand < 0.9 ? 1 : 2;
          //   }
          // }

          // Apply UI overrides: if any fan checkbox is true, force that fan to FAIL (2)
          const uiFanOverrides = [
            simulatorState.fan1,
            simulatorState.fan2,
            simulatorState.fan3,
            simulatorState.fan4,
            simulatorState.fan5,
            simulatorState.fan6,
          ];

          for (let i = 0; i < 6; i++) {
            if (uiFanOverrides[i] === true) {
              fanStatuses[i] = 2;
            }
          }

          let fanStatusBits = 0;
          for (let i = 0; i < 6; i++) {
            fanStatusBits |= fanStatuses[i] << (i * 2);
          }
          const fanStatusBuf = Buffer.alloc(2);
          fanStatusBuf.writeUInt16LE(fanStatusBits, 0);

          // console.log(`🎛️ [${ip}] Fans Status: [${fanStatusBits}]`);

          // FAN GROUP STATUS

          if (fanStatusBits === 21) {
            fanGroupStatus = [1, 1, 0, 0];
          } else if (fanStatusBits === 341) {
            fanGroupStatus = [1, 1, 1, 0];
          } else if (fanStatusBits === 1365) {
            fanGroupStatus = [1, 1, 1, 1];
          }

          const fan1 = fanStatusBits === 21 ? 1 : 0; // Example: if all fans are ON, set fan1=1, else 0
          const fan2 = fanStatusBits === 21 ? 1 : 0; // Example: if all fans are ON, set fan2=1, else 0
          const fan3 = 1;
          const fan4 = 1;

          // let failMask = 0;
          // for (let bit = 0; bit <= 5; bit++) {
          //   if (triggerAlarm && Math.random() < 0.1) failMask |= (1 << bit);
          // }

          let pwsFailCount = 0; // Random 0 or 3

          const hupsAlarms = [1, 1, 1, 1, 1, 1];
          // const hupsAlarms = [0, 0, 0, 0, 0, 0];

          let hupsAlarmsBit = 0;

          for (let i = 0; i < hupsAlarms.length; i++) {
            hupsAlarmsBit |= (hupsAlarms[i] ? 1 : 0) << i;
          }

          const hupsAlarmsBuf = Buffer.from([hupsAlarmsBit]);
          // hupsAlarmsBuf.writeUInt16LE(hupsAlarmsBit, 0);

          let failMask3 = Math.floor(Math.random() * 256); // Random 0 or 1
          let failMask4 = Math.floor(Math.random() * 256); // Random 0 or 1

          // const failBuf1 = Buffer.alloc(2);
          // const failBuf2 = Buffer.alloc(2);
          // const failBuf3 = Buffer.alloc(2);
          // const failBuf4 = Buffer.alloc(2);
          // failBuf1.writeUInt16LE(failMask1, 0);
          // failBuf2.writeUInt16LE(failMask2, 0);
          // failBuf3.writeUInt16LE(failMask3, 0);
          // failBuf4.writeUInt16LE(failMask4, 0);

          const packet = Buffer.concat([
            // Buffer.from(ip.padEnd(17, ' '), 'utf-8'), //0-16
            ipStringToAsciiHexBuffer(ip),
            Buffer.alloc(9, 0x00), // 9 bytes ZERO padding
            toFloatLE(humidity), //17-20
            toFloatLE(insideTemp), //21-24
            toFloatLE(outsideTemp), //25-28
            Buffer.from([lockStatus, doorStatus, waterLogging, waterLeakage]), //29-32
            toShortLE(outputVoltage), //33-34
            toShortLE(hupsDVC), //35-36
            toShortLE(inputVoltage), //37-38
            toShortLE(hupsBat), //39-40
            toFloatLE(batteryBackup), //41-44
            Buffer.from([
              alarmActive ? 1 : 0,
              fireAlarm,
              fanGroupStatus[0],
              fanGroupStatus[1],
              fanGroupStatus[2],
              fanGroupStatus[3],
              // PADDING_BYTE0
              // 0x43
              0,
            ]), //45-51
            fanStatusBuf, //52-53
            Buffer.from([pwsFailCount]), //54
            hupsAlarmsBuf, //55
            Buffer.from([failMask3]), //56
            Buffer.from([failMask4]), //57
          ]);

          // const len = new TextEncoder().encode(JSON.stringify(outputVoltage)).length;
          // console.log(`Byte used by packet: ${len}`);

          const status =
            isDisconnectedSim && sendCount >= 3
              ? "❌ DISCONNECTED"
              : triggerAlarm
                ? "🚨 ALARM"
                : "✅ NORMAL";
          // console.log(`📤 [${ip}] ${status} | Sending packet PACKET ${packet.toString('hex')} of COUNT #${sendCount}`);
          console.log(
            `📤 [${ip}] ${status} | Sending packet of COUNT #${sendCount}`,
          );
          // console.log(`[${ip}] Packet padding byte at offset 51: 0x${packet[51]}`);
          // console.log(
          //   "Simulator sending IP bytes:",
          //   packet.slice(0, 4)
          // );

          client.write(packet);
        }, SEND_INTERVAL);

        client.on("close", () => {
          console.warn(`🔌 [${ip}] CONNECTION CLOSED`);
          connectedDevices.delete(ip); // 🔧 NEW: Remove from map
          clearInterval(interval);
        });
      }
    });

    client.on("error", (err) => {
      console.error(`💥 [${ip}] CONNECTION ERROR:`, err.message);
      connectedDevices.delete(ip); // 🔧 NEW: Remove from map
      setTimeout(() => startDevice(ip, index), 5000);
    });

    client.on("close", () => {
      console.warn(`🔌 [${ip}] CONNECTION CLOSED`);
      connectedDevices.delete(ip); // 🔧 NEW: Remove from map
    });
  } catch (err) {
    console.error(`💥 [${ip}] START DEVICE ERROR:`, err);
    setTimeout(() => startDevice(ip, index), 5000);
  }
}

// 🔧 NEW: Central Data Dispatcher
function startDataDispatcher() {
  console.log("🚀 Starting CENTRAL DATA DISPATCHER");

  const interval = setInterval(() => {
    console.log(`\n🕒 === DISPATCHING SECOND ${currentSecond} ===`);

    // data for current second (any MAC)
    const allDataThisSecond = csvDataBySecond.get(currentSecond) || [];

    console.log(
      `📊 Found ${allDataThisSecond.length} data entries for second ${currentSecond}`,
    );

    if (allDataThisSecond.length === 0) {
      console.log(`⏭️ No data for any device at second ${currentSecond}`);
    } else {
      // Parsing each data entry to the appropriate device
      allDataThisSecond.forEach((dataRow) => {
        const targetMAC = dataRow.ip;

        console.log(`🎯 Dispatching to ${targetMAC}:`, {
          humidity: dataRow.humidity,
          temp: dataRow.inside_temp,
          outside_temp: dataRow.outside_temp,
        });

        // 3. Find the client for this MAC
        const client = connectedDevices.get(targetMAC);

        if (client && client.writable) {
          // Find device index for logging
          const deviceIndex = devices.findIndex((d) => d === targetMAC);
          sendPacketForRow(client, dataRow, targetMAC, deviceIndex);
          console.log(`✅ Data sent to ${targetMAC}`);
        } else {
          console.log(`❌ Device ${targetMAC} not connected or not writable`);
        }
      });
    }

    // Moving to next second
    const previousSecond = currentSecond;
    currentSecond++;
    console.log(
      `🔄 Moving to next second: ${previousSecond} → ${currentSecond}`,
    );

    // Check if we've reached the end of CSV timeline
    if (csvData.length > 0) {
      const maxSecond = Math.max(
        ...csvData.map((row) => parseInt(row.seconds)),
      );
      console.log(
        `📈 Max second in CSV: ${maxSecond}, Current: ${currentSecond}`,
      );

      if (currentSecond > maxSecond) {
        console.log(
          "🏁 CSV timeline completed! Switching all devices to RANDOM mode",
        );
        clearInterval(interval);
        isCSVMode = false;

        // All devices will now operate in random mode (handled in startDevice)
      }
    }
  }, 3000); // Dispatch every 3 seconds
}

async function initializeSimulator() {
  try {
    if (isCSVMode === true) {
      console.log("📄 Attempting to load CSV data...");
      csvData = await readCSV(process.env.CSV_PATH || "./sim_pack2.csv");

      preIndexCSVData();

      // 🔍 Debug: Analyze CSV data
      const uniqueMACs = [...new Set(csvData.map((row) => row.ip))];
      console.log(`🔍 CSV Analysis:`);
      console.log(`   Total rows: ${csvData.length}`);
      console.log(`   Unique MACs: ${uniqueMACs.length}`);
      console.log(`   MACs in CSV: ${uniqueMACs.join(", ")}`);

      // Show seconds distribution
      const secondsSample = [
        ...new Set(csvData.map((row) => parseInt(row.seconds))),
      ]
        .sort((a, b) => a - b)
        .slice(0, 10);
      console.log(`   First 10 seconds: [${secondsSample.join(", ")}]`);

      // Start all devices
      for (let i = 0; i < TOTAL_DEVICES; i++) {
        const ip = generateIP(i);
        startDevice(ip, i);
        devices.push(ip);
      }

      // 🔧 NEW: Start the central data dispatcher after a brief delay
      setTimeout(() => {
        startDataDispatcher();
      }, 3000);
    } else {
      console.log("❌ CSV not found, using FULL RANDOM mode...");
      isCSVMode = false;

      // Start all devices in random mode
      for (let i = 0; i < TOTAL_DEVICES; i++) {
        const ip = generateIP(i);
        console.log("MAC", typeof ip);
        startDevice(ip, i);
        devices.push(ip);
      }
    }
  } catch (err) {
    console.log("Error in starting Simulator");
  }
}

// Start the simulator
initializeSimulator();

// Graceful shutdown
process.on("SIGINT", () => {
  console.log("\n🛑 Stopping simulator...");
  process.exit(0);
});

/* // Start all devices
let index = 0;
const spawnInterval = setInterval(() => {
  if (index >= TOTAL_DEVICES) {
    clearInterval(spawnInterval);
    console.log('✅ All simulated devices started.');
    return;
  }
  const ip = generateMac(index);
  startDevice(ip, index);
  devices.push(ip);
  index++;
}, 10);
 */
